package com.servlet.first;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class FirstDataBase {

	public static void main(String[] args) {
		
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			String url="jdbc:mysql://localhost:3306/j2ee_db";
			Connection con=DriverManager.getConnection(url,"root","root");
			String s="insert into student values(?,?,?,?)";
			PreparedStatement p=con.prepareStatement(s);
			p.setString(1,"kathir");
			p.setString(2, "mech");
			p.setString(3,"kathir1@gmail");
			p.setString(4, "12345678");
			int c=p.executeUpdate();
			if(c>=1) {
				System.out.println("updated");
			}
			else {
				System.out.println("not updated");
			}
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
		catch(ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

}
